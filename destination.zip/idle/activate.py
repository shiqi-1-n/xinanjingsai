import os
import menu
import tasks
import tasksmanager
from start import main

main()
if __name__ == "__main__":
    main()